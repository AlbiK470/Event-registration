import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PrivateRoute from './components/PrivateRoute';
import AdminUserManagement from './components/AdminUserManagement';
import Login from './components/Login';
import Register from './components/Register';
import EventList from './components/EventList';

const App = () => {
    return (
        <Router>
            <Routes>
                <Route path="/login" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route
                    path="/events"
                    element={
                        <PrivateRoute>
                            <EventList />
                        </PrivateRoute>
                    }
                />
                <Route
                    path="/admin/users"
                    element={
                        <PrivateRoute>
                            <AdminUserManagement />
                        </PrivateRoute>
                    }
                />
            </Routes>
        </Router>
    );
};

export default App;
