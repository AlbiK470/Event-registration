import React, { useState } from 'react';
import axios from 'axios';

const Login = () => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const onSubmit = async e => {
        e.preventDefault();
        try {
            const res = await axios.post('http://localhost:5000/api/users/login', { email, password });
            console.log(res); 
            if (res.data && res.data.token) {
                localStorage.setItem('token', res.data.token);
                
            } else {
                console.error('Login response does not contain token:', res.data);
            }
        } catch (err) {
            console.error('Error during login:', err);
            if (err.response && err.response.data) {
                console.error('Login error response data:', err.response.data);
            }
        }
    };

    return (
        <form onSubmit={onSubmit}>
            <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={e => setEmail(e.target.value)}
            />
            <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={e => setPassword(e.target.value)}
            />
            <button type="submit">Login</button>
        </form>
    );
};

export default Login;
