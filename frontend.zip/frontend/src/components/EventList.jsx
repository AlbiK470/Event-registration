import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EventList = () => {
    const [events, setEvents] = useState([]);
    const [newEvent, setNewEvent] = useState({ name: '', description: '', date: '', location: '' });
    const [editingEvent, setEditingEvent] = useState(null);
    const [updatedEvent, setUpdatedEvent] = useState({ name: '', description: '', date: '', location: '' });
    const [error, setError] = useState(null);

    useEffect(() => {
        fetchEvents();
    }, []);

    const fetchEvents = async () => {
        try {
            const res = await axios.get('http://localhost:5000/api/events');
            setEvents(res.data);
        } catch (err) {
            setError(err.response?.data || 'Server error');
            console.error(err.response?.data || 'Server error');
        }
    };

    const addEvent = async () => {
        try {
            const res = await axios.post('http://localhost:5000/api/events', newEvent);
            setEvents([...events, res.data]);
            setNewEvent({ name: '', description: '', date: '', location: '' });
        } catch (err) {
            setError(err.response?.data || 'Server error');
            console.error(err.response?.data || 'Server error');
        }
    };

    const deleteEvent = async (id) => {
        try {
            // Tokeni i autorizimit
            const token = localStorage.getItem('token'); 
            console.log(`Deleting event with ID: ${id}`); 
            const res = await axios.delete(`http://localhost:5000/api/events/${id}`, {
                headers: {
                    'x-auth-token': token
                }
            });
            console.log(res); 
            if (res.status === 200) {
                setEvents(events.filter(event => event._id !== id));
            } else {
                setError(res.data.msg || 'Server error');
            }
        } catch (err) {
            setError(err.response?.data || 'Server error');
            console.error(err.response?.data || 'Server error');
        }
    };

    const startEditing = (event) => {
        setEditingEvent(event);
        setUpdatedEvent({ name: event.name, description: event.description, date: event.date, location: event.location });
    };

    const cancelEditing = () => {
        setEditingEvent(null);
        setUpdatedEvent({ name: '', description: '', date: '', location: '' });
    };

    const updateEvent = async () => {
        try {
            const token = localStorage.getItem('token'); 
            const res = await axios.put(`http://localhost:5000/api/events/${editingEvent._id}`, updatedEvent, {
                headers: {
                    'x-auth-token': token
                }
            });
            setEvents(events.map(event => event._id === editingEvent._id ? res.data : event));
            cancelEditing();
        } catch (err) {
            setError(err.response?.data || 'Server error');
            console.error(err.response?.data || 'Server error');
        }
    };

    const handleNewEventChange = (e) => {
        setNewEvent({ ...newEvent, [e.target.name]: e.target.value });
    };

    const handleUpdatedEventChange = (e) => {
        setUpdatedEvent({ ...updatedEvent, [e.target.name]: e.target.value });
    };

    return (
        <div>
            <h1>Events</h1>
            {error && <p style={{ color: 'red' }}>{error}</p>}
            <ul>
                {events.map(event => (
                    <li key={event._id}>
                        <strong>{event.name}</strong>
                        <p>{event.description}</p>
                        <p>{new Date(event.date).toLocaleDateString()}</p>
                        <p>{event.location}</p>
                        <p>Organizer: {event.organizer?.name} ({event.organizer?.email})</p>
                        <button onClick={() => deleteEvent(event._id)}>Delete</button>
                        <button onClick={() => startEditing(event)}>Edit</button>
                    </li>
                ))}
            </ul>

            <div>
                <h2>Add New Event</h2>
                <input
                    type="text"
                    name="name"
                    placeholder="Name"
                    value={newEvent.name}
                    onChange={handleNewEventChange}
                />
                <input
                    type="text"
                    name="description"
                    placeholder="Description"
                    value={newEvent.description}
                    onChange={handleNewEventChange}
                />
                <input
                    type="date"
                    name="date"
                    value={newEvent.date}
                    onChange={handleNewEventChange}
                />
                <input
                    type="text"
                    name="location"
                    placeholder="Location"
                    value={newEvent.location}
                    onChange={handleNewEventChange}
                />
                <button onClick={addEvent}>Add</button>
            </div>

            {editingEvent && (
                <div>
                    <h2>Edit Event</h2>
                    <input
                        type="text"
                        name="name"
                        placeholder="Name"
                        value={updatedEvent.name}
                        onChange={handleUpdatedEventChange}
                    />
                    <input
                        type="text"
                        name="description"
                        placeholder="Description"
                        value={updatedEvent.description}
                        onChange={handleUpdatedEventChange}
                    />
                    <input
                        type="date"
                        name="date"
                        value={updatedEvent.date}
                        onChange={handleUpdatedEventChange}
                    />
                    <input
                        type="text"
                        name="location"
                        placeholder="Location"
                        value={updatedEvent.location}
                        onChange={handleUpdatedEventChange}
                    />
                    <button onClick={updateEvent}>Update</button>
                    <button onClick={cancelEditing}>Cancel</button>
                </div>
            )}
        </div>
    );
};

export default EventList;
