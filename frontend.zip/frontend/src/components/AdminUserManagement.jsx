import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminUserManagement = () => {
    const [users, setUsers] = useState([]);
    const [editingUser, setEditingUser] = useState(null);
    const [editedName, setEditedName] = useState('');
    const [editedEmail, setEditedEmail] = useState('');
    const [editedRole, setEditedRole] = useState('');

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const res = await axios.get('http://localhost:5000/api/users/all', {
                    headers: { 'x-auth-token': localStorage.getItem('token') }
                });
                setUsers(res.data);
            } catch (err) {
                console.error('Error fetching users:', err.response ? err.response.data : err.message);
            }
        };

        fetchUsers();
    }, []);

    const deleteUser = async (userId) => {
        try {
            await axios.delete(`http://localhost:5000/api/users/${userId}`, {
                headers: { 'x-auth-token': localStorage.getItem('token') }
            });
            setUsers(users.filter(user => user._id !== userId));
        } catch (err) {
            console.error('Error deleting user:', err.response ? err.response.data : err.message);
        }
    };

    const editUser = (user) => {
        setEditingUser(user);
        setEditedName(user.name);
        setEditedEmail(user.email);
        setEditedRole(user.role);
    };

    const updateUser = async () => {
        try {
            const updatedUser = {
                name: editedName,
                email: editedEmail,
                role: editedRole
            };
            await axios.put(`http://localhost:5000/api/users/${editingUser._id}`, updatedUser, {
                headers: { 'x-auth-token': localStorage.getItem('token') }
            });
            setUsers(users.map(user => (user._id === editingUser._id ? { ...user, ...updatedUser } : user)));
            setEditingUser(null);
        } catch (err) {
            console.error('Error updating user:', err.response ? err.response.data : err.message);
        }
    };

    return (
        <div>
            <h2>Admin User Management</h2>
            <ul>
                {users.map(user => (
                    <li key={user._id}>
                        {user.name} - {user.email} - {user.role}
                        <button onClick={() => deleteUser(user._id)}>Delete</button>
                        <button onClick={() => editUser(user)}>Edit</button>
                    </li>
                ))}
            </ul>
            {editingUser && (
                <div>
                    <h3>Edit User</h3>
                    <input
                        type="text"
                        value={editedName}
                        onChange={(e) => setEditedName(e.target.value)}
                    />
                    <input
                        type="email"
                        value={editedEmail}
                        onChange={(e) => setEditedEmail(e.target.value)}
                    />
                    <select value={editedRole} onChange={(e) => setEditedRole(e.target.value)}>
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                    </select>
                    <button onClick={updateUser}>Save</button>
                    <button onClick={() => setEditingUser(null)}>Cancel</button>
                </div>
            )}
        </div>
    );
};

export default AdminUserManagement;
