const express = require('express');
const auth = require('../middleware/auth');
const User = require('../models/User');

const router = express.Router();

// Middleware per te kuptuar nese eshte admini
const adminAuth = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ msg: 'Access denied' });
    }
    next();
};

// Merr userat ( e lejuar vetem per adminin )
router.get('/', auth, adminAuth, async (req, res) => {
    try {
        const users = await User.find().select('-password');
        res.json(users);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// Merr userat sipas ID-se ( e lejuar vetem per adminin )
router.get('/:id', auth, adminAuth, async (req, res) => {
    try {
        const user = await User.findById(req.params.id).select('-password');
        if (!user) return res.status(404).json({ msg: 'User not found' });
        res.json(user);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// Krijo usera ( e lejuar vetem per adminin )
router.post('/', auth, adminAuth, async (req, res) => {
    const { name, email, password, role } = req.body;
    try {
        let user = await User.findOne({ email });
        if (user) return res.status(400).json({ msg: 'User already exists' });

        user = new User({ name, email, password, role });
        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(password, salt);
        await user.save();

        res.json(user);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// Perditeso userat ( e lejuar vetem per adminin )
router.put('/:id', auth, adminAuth, async (req, res) => {
    const { name, email, password, role } = req.body;
    try {
        const user = await User.findById(req.params.id);
        if (!user) return res.status(404).json({ msg: 'User not found' });

        if (password) {
            const salt = await bcrypt.genSalt(10);
            user.password = await bcrypt.hash(password, salt);
        }

        user.name = name || user.name;
        user.email = email || user.email;
        user.role = role || user.role;
        await user.save();

        res.json(user);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// Fshirja e userave ( e lejuar vetem per adminin )
router.delete('/:id', auth, adminAuth, async (req, res) => {
    try {
        const user = await User.findByIdAndDelete(req.params.id);
        if (!user) return res.status(404).json({ msg: 'User not found' });

        res.json({ msg: 'User removed' });
    } catch (err) {
        res.status(500).send('Server error');
    }
});

module.exports = router;
