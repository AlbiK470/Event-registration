const express = require('express');
const auth = require('../middleware/auth');
const Attendee = require('../models/Attendee');

const router = express.Router();

// rregjistrimi i nje personi
router.post('/:eventId', auth, async (req, res) => {
    try {
        const newAttendee = new Attendee({
            user: req.user.id,
            event: req.params.eventId
        });
        const attendee = await newAttendee.save();
        res.json(attendee);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// merr shikuesit
router.get('/:eventId', async (req, res) => {
    try {
        const attendees = await Attendee.find({ event: req.params.eventId }).populate('user', ['name', 'email']);
        res.json(attendees);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

module.exports = router;
