const express = require('express');
const auth = require('../middleware/auth');
const Event = require('../models/Event');

const router = express.Router();

// Krijimi i eventit
router.post('/', auth, async (req, res) => {
    const { name, description, date, location } = req.body;
    try {
        const newEvent = new Event({
            name,
            description,
            date,
            location,
            organizer: req.user.id
        });
        const event = await newEvent.save();
        res.json(event);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// Shfaq eventet
router.get('/', async (req, res) => {
    try {
        const events = await Event.find().populate('organizer', ['name', 'email']);
        res.json(events);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// merr eventin sipas ID-se
router.get('/:id', async (req, res) => {
    try {
        const event = await Event.findById(req.params.id).populate('organizer', ['name', 'email']);
        if (!event) return res.status(404).json({ msg: 'Event not found' });
        res.json(event);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// Perditeso eventin
router.put('/:id', auth, async (req, res) => {
    const { name, description, date, location } = req.body;
    try {
        const event = await Event.findById(req.params.id);
        if (!event) return res.status(404).json({ msg: 'Event not found' });

        // Check-o nese user eshte admin apo jo
        if (event.organizer.toString() !== req.user.id && req.user.role !== 'admin') {
            return res.status(401).json({ msg: 'Not authorized' });
        }

        const updatedEvent = await Event.findByIdAndUpdate(
            req.params.id,
            { name, description, date, location },
            { new: true }
        );
        res.json(updatedEvent);
    } catch (err) {
        res.status(500).send('Server error');
    }
});

// Fshirja e eventit
router.delete('/:id', auth, async (req, res) => {
    try {
        const event = await Event.findById(req.params.id);
        if (!event) return res.status(404).json({ msg: 'Event not found' });

        // Check-o nese useri esht admin apo jo
        if (event.organizer.toString() !== req.user.id && req.user.role !== 'admin') {
            return res.status(401).json({ msg: 'Not authorized' });
        }

        await Event.findByIdAndDelete(req.params.id);
        res.json({ msg: 'Event removed' });
    } catch (err) {
        console.error(`Server error: ${err.message}`);
        res.status(500).send('Server error');
    }
});

module.exports = router;
